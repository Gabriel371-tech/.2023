﻿CREATE TABLE agencia(
numagencia serial primary key,
nomeagencia varchar(50),
cidadeagencia varchar(100));

CREATE TABLE cliente(
Cpfcliente char(11) primary key,
ididentificador numeric (5,2),
ruacliente varchar(50),
cidadclientee varchar(50),
numcliente varchar(10));

CREATE TABLE emprestimo(
idemprestimo serial primary key,
numagencia int,
valormeprestimo numeric(10,2),
CONSTRAINT agenciaemprestimo
FOREIGN KEY (numagencia)
REFERENCES agencia(numagencia));

CREATE TABLE devedor(
idcliente int,
idemprestimo int,
PRIMARY KEY(idcliente, idemprestimo),
CONSTRAINT clientedevedor
FOREIGN KEY idcliente
REFERENCES cliente(idcliente),
CONSTRAINT emprestimodevedor
FOREIGN KEY idemprestimo
REFERENCES emprestimo(idemprestimo));


CREATE TABLE conta(
idconta serial primary key,
idagencia int,
Saldocon numeric(5,2),
CONSTRAINT contaagencia
FOREIGN KEY (numagencia)
REFERENCES agencia(numagencia));

CREATE TABLE depositante(
idcliente int,
idconta int,
PRIMARY KEY (idcliente, idconta),
CONSTRAINT clientedepositante




































































































































































































































































