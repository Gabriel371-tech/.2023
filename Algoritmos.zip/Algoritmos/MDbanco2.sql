﻿CREATE TABLE Cliente(
codcliente serial primary key,
nomecliente varchar(50),
estadocliente varchar(50),
cidadecliente varchar(50),
ruacliente varchar(50),
cpfcliente char(11),
cepcliente char(9),
status varchar(50),
limitecred varchar(52));

CREATE TABLE Telefone(
cod_telefone serial primary key,
codcliente int,
numero int,
CONSTRAINT ClienteTelefone
FOREIGN KEY (codcliente)
REFERENCES Cliente(codcliente));

 CREATE TABLE Pedido(
codpedido serial primary key,
data_pedido date,
codcliente int,
PRIMARY KEY (codcliente),
CONSTRAINT clientepedido
FOREIGN KEY (codcliente)
REFERENCES Cliente(codcliente));

CREATE TABLE Categoria(
codcategoria serial primary key,
nomecategoria varchar(50));

CREATE TABLE Produto(
codproduto serial primary key,
nome varchar(50),
preço numeric(5,2),
codcategoria int,
PRIMARY KEY(cocategoria),
CONSTRAINT CategoriaProduto
FOREIGN KEY (codcategoria)
REFERENCES Categoria(codcategoria));

CREATE TABLE Contem(
idcontem serial primary key,
codproduto int,
codpedido int,
quantidade numeric(5,2),
valortotal numeric(5,2),
PRIMARY KEY(Contem))
FOREIGN KEY (codproduto))
REFERENCES Produto(codproduto)
CONSTRAINT PedidoContem
FOREIGN KEY (codpedido)
REFERENCES Pedido(codpedido));

