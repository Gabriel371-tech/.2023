﻿CREATE TABLE cliente(
idcliente serial primary key,
rua varchar(100),
numero varchar(10),
bairro varchar(50),
cidade varchar(80));

CREATE TABLE vendedor(
idvendedor serial primary key,
nome varchar(100),
salario numeric(5,2));

CREATE TABLE pedido(
idpedido serial primary key,
prazoentrega date,
idcliente int,
idvendedor int,
CONSTRAINT pedidocliente
FOREIGN KEY(idcliente)
REFERENCES cliente(idcliente),
CONSTRAINT pedidovendedor
FOREIGN KEY(idvendedor)
REFERENCES vendedor(idvendedor));

CREATE TABLE produto(
idproduto serial primary key,
valor numeric(5,2),
descriçao varchar(100));

CREATE TABLE itempedido(
iditempedido serial primary key,
quantidade numeric(5,2),
idpedido int,
CONSTRAINT itempedidopedido
FOREIGN KEY (idpedido)
REFERENCES pedido(idpedido));

CREATE TABLE itempedidoproduto(
iditempedido int,
idproduto int,
CONSTRAINT itempedido_pkey
PRIMARY KEY(iditempedido, idproduto),
CONSTRAINT itempedidoproduto
FOREIGN KEY (iditempedido)
REFERENCES itempedido(iditempedido),
CONSTRAINT  itempedidoprodutotop
FOREIGN KEY (idproduto)
REFERENCES produto(idproduto));




