﻿﻿create table aluno(
idaluno serial not null,
nomealuno varchar(40),
cidadealuno varchar(40),
cursoaluno varchar(30),
rmaluno integer,
constraint pk_akuno primary key(idaluno));

create table professor(
idprofessor serial not null,
nomeprofessor varchar(40),
endereco varchar(15),
graduacao int,
categoria varchar(25),
constraint pk_professor primary key(idprofessor));
