﻿create table Clientes (
idCliente serial not null PRIMARY KEY, 
nomecliente varchar(30) not null,
CPF char(11) not null,
telefone numeric not null);

insert into Clientes(idCliente, nomeCliente, CPF, telefone)
values(1, 'Gabriel', 88888888888, 55555555),
(2, 'gabriel', 77777777777, 44444444),
(3, 'Morales', 66666666666, 33333333);

select *from Clientes Where idCliente =1;
alter table Clientes
rename telefone to telephone;
select *from Clientes;
select c.nomeCliente, p.descricao 
from Clientes c inner join Pedido p on
c.idCliente= p.idCliente;

create table Pedido(
idPedido serial not null PRIMARY KEY,
descricao varchar(30),
idProduto int not null,
idCliente int not null,
Constraint fk_Produto Foreign key (idProduto)
References Produto(idProduto),
Constraint fk_Cliente Foreign key (idCliente)
References Clientes(idCliente));

drop table Pedido;
select *from Pedido Where idCliente =1;

insert into Pedido(idPedido, descricao, idProduto, idCliente)
values (1, 'Sorvete de Chocolate', 1, 1),
(2, 'Sorvete de Brigadeiro', 2, 2),
(3, 'Sorvete de Chocolate Branco', 3, 3);

create table Produto(
idProduto serial not null Primary key,
descricao varchar(30),
valor decimal(10,2) not null);

insert into Produto(idProduto, descricao, valor)
values(1, 'Sorvete', 15.00),
(2, 'Sorvete de chocolate', 35.00),
(3, 'Sorvete LeiteNinho', 45.00);

select *from Produto Where idProduto =1;
