﻿﻿create table aluno(
idaluno serial not null,
nomealuno varchar(40),
cidadealuno varchar(40),
cursoaluno varchar(30),
rmaluno integer,
constraint pk_akuno primary key(idaluno));

create table usuario(
idusuario serial not null,
nomeusuario varchar(30),
loginusuario varchar(40),
senhausuario varchar(40),
constraint pk_usuario primary key(idusuario)
);


create table professor(
idprofessor serial not null,
nomeprofessor varchar(40),
enderecoprofessor varchar(15),
graduacaoprofessor varchar(25),
categoriaprofessor int,
constraint pk_professor primary key(idprofessor));