﻿create table cliente( 

                idcliente serial not null, 

                nomecliente varchar(40), 

                enderecocliente varchar(40), 

                cidadecliente varchar(50), 

                estadocliente char(2), 

                cepcliente char(8), 

                cnpjcliente char(14), 

                constraint pk_cliente primary key(idcliente) 

); 

 

create table vendedor( 

                idvendedor serial not null, 

                nomevendedor varchar(40), 

                salfixovendedor numeric(9,2), 

                faixacomvendedor char(1), 

                constraint pk_vendedor primary key(idvendedor) 

); 

 

create table produto( 

                idproduto serial not null, 

                descproduto varchar(30), 

                unidadeproduto varchar(10), 

                valorproduto numeric(7,2), 

                constraint pk_produto primary key(idproduto) 

); 

 

create table pedido( 

                idpedido serial not null, 

                datapedido date, 

                prazopedido integer, 

                totalpedido numeric(9,2), 

                idcliente integer, 

                idvendedor integer, 

                constraint pk_pedido primary key(idpedido), 

                constraint fk_pedido_cliente foreign key(idcliente)  
                               references cliente(idcliente), 

                constraint fk_pedido_vendedor foreign key(idvendedor) 
                               references vendedor(idvendedor) 

); 


create table itempedido(
               idpedido integer not null,
               idproduto integer not null,
               quantidade numeric(5,2),
               totalitem numeric(5,2),
               constraint pk_itempedido primary key (idpedido, idproduto),
               constraint fk_itempedido_pedido foreign key (idpedido)
				references pedido(idpedido),
               constraint fk_itempedido_produto foreign key (idproduto)
				references produto(idproduto)


);